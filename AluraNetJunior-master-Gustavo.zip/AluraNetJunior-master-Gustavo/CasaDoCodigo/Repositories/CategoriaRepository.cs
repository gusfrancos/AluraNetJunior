﻿using CasaDoCodigo.Models;
using CasaDoCodigo.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasaDoCodigo.Repositories
{
    public interface ICategoriaRepository
    {
        Task CriarCategoriaPorNome(string nome);
        Categoria ProcurarCategoriaPorNome(string nome);
        IList<Categoria> GetCategorias();
        Task<List<Categoria>> GetCategorias(string nomecategoria);
    }

    public class CategoriaRepository : BaseRepository<Categoria>, ICategoriaRepository
    {
        private readonly IHttpContextAccessor contextAccessor;
        
        public CategoriaRepository(ApplicationContext contexto,
            IHttpContextAccessor contextAccessor) : base(contexto)
        {
            this.contextAccessor = contextAccessor;
        }

        public IList<Categoria> GetCategorias()
        {
            return dbSet.ToList();
        }

        public async Task<List<Categoria>> GetCategorias(string nomecategoria)
        {
            List<Categoria> temp = dbSet.Where(p => p.Nome.Contains(nomecategoria.ToUpper())).ToList();
            return temp;
        }

        public Categoria ProcurarCategoriaPorNome(string nome)
        {
            var categoria = contexto.Set<Categoria>()
                            .Where(p => p.Nome.ToUpper() == nome.ToUpper())
                            .SingleOrDefault();

            return categoria;
        }
               
        public async Task CriarCategoriaPorNome(string nome)
        {
            if (this.ProcurarCategoriaPorNome(nome) == null)
            {
                dbSet.Add(new Categoria(nome));
                await contexto.SaveChangesAsync();
            }
        }
    }
}
