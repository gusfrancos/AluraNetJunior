﻿using CasaDoCodigo.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CasaDoCodigo.Repositories
{
    public interface IProdutoRepository
    {
        Task SaveProdutos(List<Livro> livros);
        Task<List<Produto>> GetProdutos();
        Task<List<Produto>> GetProdutos(string nomeproduto);
    }
}