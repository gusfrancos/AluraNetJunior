﻿class Site {

    postBuscarProdutoCategoria(data) {

        let token = $('[name=__RequestVerificationToken]').val();

        let headers = {};
        headers['RequestVerificationToken'] = token;

        $.ajax({
            url: '/pedido/buscadeprodutos',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            headers: headers
        }).done(function (response) {
            let BuscaDeProdutosViewModel = response.BuscaDeProdutosViewModel;
            

           
        });
    }
}

var site = new Site();