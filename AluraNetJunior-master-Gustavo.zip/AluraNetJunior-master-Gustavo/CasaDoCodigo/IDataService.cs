﻿using System.Threading.Tasks;

namespace CasaDoCodigo
{
    interface IDataService
    {
        Task InicializaDB();
    }
}