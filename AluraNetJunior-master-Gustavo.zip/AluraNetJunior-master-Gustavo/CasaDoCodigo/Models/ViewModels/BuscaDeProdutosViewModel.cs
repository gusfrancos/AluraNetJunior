﻿using System.Collections.Generic;

namespace CasaDoCodigo.Models.ViewModels
{
    public class BuscaDeProdutosViewModel
    {
        public BuscaDeProdutosViewModel(IList<Categoria> categoria, IList<Produto> produto)
        {
            Categorias = categoria;
            Produtos = produto;
        }

        public IList<Categoria> Categorias { get; }
        public IList<Produto> Produtos { get; }
    }
}
